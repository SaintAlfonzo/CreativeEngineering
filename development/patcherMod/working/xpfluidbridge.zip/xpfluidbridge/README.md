# XP Fluid Bridge

A small Forge 1.19.2 Mixin mod that patches PneumaticCraft: Repressurized's
Memory Stick (and its XP-orb auto-absorb path) to store/read Create:
Enchantment Industry's **Liquid Experience** fluid instead of PneumaticCraft's
own **Memory Essence** fluid.

## What's solid vs. what needs your verification

**Derived directly from your pasted source/bytecode - high confidence:**
- `MemoryStickItemMixin` targets (`lambda$use$0`, `lambda$appendHoverText$2`,
  `lambda$initCapabilities$4`) - confirmed via javap against the actual
  compiled class.
- `PneumaticCraftUtilsMixin` target (`fillTankWithOrb`) - confirmed from
  real (non-decompiled) source you provided.
- The field descriptor being redirected
  (`Lme/desht/pneumaticcraft/common/core/ModFluids;MEMORY_ESSENCE:Lnet/minecraftforge/registries/RegistryObject;`)
  - confirmed from the constant pool.
- The fact that you do **not** need to touch any XP-to-mB ratio math -
  `XPFluidManager` already looks the ratio up per-fluid from a data-driven
  registry.

**Templated / needs your verification - lower confidence:**
- `FluidBridge.LIQUID_XP_ID` (`create_enchantment_industry:liquid_experience`)
  - this is my best inference from public sources, not something I could
    confirm against your actual jar. Verify it the same way you confirmed
    Create's tank NBT earlier (e.g. `/data get` on a block/item holding the
    real fluid, or check CEI's registered fluids via a `/forge` or JEI
    lookup).
- `build.gradle` - a best-known-good template for wiring ForgeGradle +
  SpongePowered Mixin on 1.19.2. I could not run an actual build in this
  environment (no network access to Forge's/SpongePowered's Maven here), so
  treat the plugin/Forge/mapping version numbers as a starting point, not a
  guaranteed-working pin. The CurseMaven coordinates for PneumaticCraft and
  Create: Enchantment Industry are **placeholders and will not resolve** -
  replace `PROJECTID`/`FILEID` with the real values for your installed
  versions (or point at local jars if you prefer).

## Setup

1. Fix the placeholder Maven coordinates and Forge version in `build.gradle`.
2. Rename the `net.yourpack.xpfluidbridge` package throughout if you want
   your own namespace (also update `mixins.xpfluidbridge.json`'s `package`
   field to match).
3. `./gradlew build` (or your platform's `gradlew.bat`).
4. Still separately: register Create: Enchantment Industry's Liquid
   Experience fluid with PneumaticCraft's `XPFluidManager` at the correct
   ratio (your tested "20x denser" figure) via whatever data-driven
   mechanism your PC:R version exposes for this (KubeJS recipe, CraftTweaker
   script, etc.) - this mod does not do that registration for you, it only
   redirects *which* fluid the Memory Stick reads/writes.

## Verifying it actually works (rather than silently no-op'ing)

Set your logging to at least `DEBUG` for the `XPFluidBridge` logger and
watch for these lines:

- On startup: `Startup check OK - ... is registered, redirect is active.`
  If you instead see `Startup check FAILED`, either CEI isn't loaded yet at
  that point (check again once the world is fully loaded) or the fluid id
  is wrong for your version.
- On sneak-right-click / right-click with a Memory Stick:
  `lambda$use$0 (fill/drain) fluid lookup redirected -> ...`
- On hovering a Memory Stick in your inventory:
  `lambda$appendHoverText$2 (tooltip) fluid lookup redirected -> ...`
- On XP-orb pickup with a Memory Stick set to absorb:
  `fillTankWithOrb (auto-absorb) fluid lookup redirected -> ...`

**If you never see these lines fire**, that's the same silent-failure
pattern we kept running into with the squeezer/bottling recipes earlier in
this whole process - it means the Mixin loaded but isn't matching, most
likely because:
- PC:R got updated and the lambda numbering shifted (re-run `javap` on the
  new `MemoryStickItem.class` and compare method names against
  `MemoryStickItemMixin`'s targets), or
- the Mixin config's mapping/compatibility settings don't match your
  toolchain (official vs. SRG mappings mismatch).

## Known open items not covered by this mod

- **Tank capacity**: `initCapabilities` still hardcodes `512000` (mB) as the
  Memory Stick's max capacity, independent of which fluid is inside. Since
  Liquid Experience is ~20x denser than Memory Essence, the same stick will
  now hold ~20x more max XP than PC:R's original design intended, unless you
  also patch that constant down. This mod intentionally leaves that as your
  design call rather than assuming an answer.
- **Sophisticated Backpacks' Experience Pump upgrade** is not patched here -
  that's a separate class/mod entirely. If you want it unified too, that's
  an additional Mixin target to work out from SBP's actual source.
- **Cosmetic/tooltip text**: even after this patch, PC:R's own UI strings
  will still say "Memory Essence" by name in a couple of places unless you
  override the relevant lang keys via a resource pack - that's a much
  lighter lift than anything here and doesn't require Java changes.
