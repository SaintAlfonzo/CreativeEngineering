package net.yourpack.xpfluidbridge.mixin;

import me.desht.pneumaticcraft.common.core.ModFluids;
import me.desht.pneumaticcraft.common.item.MemoryStickItem;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.registries.RegistryObject;
import net.yourpack.xpfluidbridge.FluidBridge;
import net.yourpack.xpfluidbridge.XPFluidBridgeMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Targets confirmed via javap against the compiled MemoryStickItem.class:
 *
 *   lambda$use$0               - fill/drain interaction (2x "new FluidStack",
 *                                  1x XPFluidManager.getXPRatio lookup)
 *   lambda$appendHoverText$2   - tooltip XP-stored ratio lookup
 *   lambda$initCapabilities$4  - the tank's accepted-fluid predicate
 *
 * lambda$use$1 does NOT reference ModFluids.MEMORY_ESSENCE (it's just the
 * empty/full click sound logic) and is intentionally NOT targeted here.
 *
 * WARNING: these lambda names are compiler-assigned based on lambda
 * order-of-appearance in PC:R's source. If a future PC:R update adds,
 * removes, or reorders a lambda earlier in use()/appendHoverText(), these
 * names can silently shift (e.g. lambda$use$0 -> lambda$use$1) and this
 * Mixin will stop matching with NO error - Mixin just won't find the
 * instruction pattern and skip it quietly. Re-run javap against the new
 * MemoryStickItem.class after any PneumaticCraft update before trusting
 * this still applies. The startup/debug logging below is there specifically
 * so a silent match failure is at least visible in the log (no "swap fired"
 * messages appearing when a player uses a Memory Stick is your signal that
 * something has drifted).
 */
@Mixin(MemoryStickItem.class)
public abstract class MemoryStickItemMixin {

    @Redirect(
            method = "lambda$use$0",
            at = @At(
                    value = "FIELD",
                    target = "Lme/desht/pneumaticcraft/common/core/ModFluids;MEMORY_ESSENCE:Lnet/minecraftforge/registries/RegistryObject;",
                    opcode = org.objectweb.asm.Opcodes.GETSTATIC
            )
    )
    private static RegistryObject<Fluid> xpfluidbridge$swapInUseHandler() {
        RegistryObject<Fluid> swapped = FluidBridge.resolveOrFallback(ModFluids.MEMORY_ESSENCE);
        XPFluidBridgeMod.LOGGER.debug("[XPFluidBridge] lambda$use$0 (fill/drain) fluid lookup redirected -> {}", swapped.getId());
        return swapped;
    }

    @Redirect(
            method = "lambda$appendHoverText$2",
            at = @At(
                    value = "FIELD",
                    target = "Lme/desht/pneumaticcraft/common/core/ModFluids;MEMORY_ESSENCE:Lnet/minecraftforge/registries/RegistryObject;",
                    opcode = org.objectweb.asm.Opcodes.GETSTATIC
            )
    )
    private static RegistryObject<Fluid> xpfluidbridge$swapInTooltip() {
        RegistryObject<Fluid> swapped = FluidBridge.resolveOrFallback(ModFluids.MEMORY_ESSENCE);
        XPFluidBridgeMod.LOGGER.debug("[XPFluidBridge] lambda$appendHoverText$2 (tooltip) fluid lookup redirected -> {}", swapped.getId());
        return swapped;
    }

    @Redirect(
            method = "lambda$initCapabilities$4",
            at = @At(
                    value = "FIELD",
                    target = "Lme/desht/pneumaticcraft/common/core/ModFluids;MEMORY_ESSENCE:Lnet/minecraftforge/registries/RegistryObject;",
                    opcode = org.objectweb.asm.Opcodes.GETSTATIC
            )
    )
    private static RegistryObject<Fluid> xpfluidbridge$swapInTankPredicate() {
        RegistryObject<Fluid> swapped = FluidBridge.resolveOrFallback(ModFluids.MEMORY_ESSENCE);
        // This one fires once per capability check (fairly often - opening
        // inventory, JEI hover, etc.) so it's logged at TRACE rather than
        // DEBUG to avoid flooding the log; bump your logger config to TRACE
        // if you specifically need to confirm this path is firing.
        XPFluidBridgeMod.LOGGER.trace("[XPFluidBridge] lambda$initCapabilities$4 (tank accept-predicate) fluid redirected -> {}", swapped.getId());
        return swapped;
    }
}
