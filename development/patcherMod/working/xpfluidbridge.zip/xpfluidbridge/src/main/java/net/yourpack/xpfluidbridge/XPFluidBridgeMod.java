package net.yourpack.xpfluidbridge;

import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * XP Fluid Bridge
 *
 * Patches PneumaticCraft: Repressurized's Memory Stick (and its XP-orb
 * auto-absorb path) to store/read Create: Enchantment Industry's
 * "Liquid Experience" fluid instead of PneumaticCraft's own Memory Essence.
 *
 * This mod does NOT touch the mB:XP ratio math - PneumaticCraft's
 * XPFluidManager already looks that up per-fluid from a data-driven
 * registry. You still need to register Liquid Experience with the correct
 * ratio via that system (KubeJS "experience_fluid" style recipe, or
 * whatever your PC:R version calls it) separately from this mod.
 */
@Mod(XPFluidBridgeMod.MODID)
public class XPFluidBridgeMod {

    public static final String MODID = "xpfluidbridge";
    public static final Logger LOGGER = LogManager.getLogger("XPFluidBridge");

    public XPFluidBridgeMod() {
        LOGGER.info("[XPFluidBridge] Loading - redirecting PneumaticCraft Memory Stick fluid identity to Create: Enchantment Industry Liquid Experience");
        LOGGER.info("[XPFluidBridge] Target fluid id: {}", FluidBridge.LIQUID_XP_ID);

        // Fire an early presence check so the log clearly shows, at startup,
        // whether the target fluid was actually found - rather than only
        // discovering a missing-dependency problem the first time a player
        // right-clicks a Memory Stick.
        FluidBridge.logStartupDiagnostic();
    }
}
