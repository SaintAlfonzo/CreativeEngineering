package net.yourpack.xpfluidbridge;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.apache.logging.log4j.Logger;

/**
 * Central place that knows what fluid we're redirecting PneumaticCraft's
 * Memory Essence references to.
 *
 * IMPORTANT: update LIQUID_XP_ID below to match Create: Enchantment
 * Industry's ACTUAL registered fluid name for your installed version.
 * "create_enchantment_industry:liquid_experience" is my best inference
 * from public sources - I was not able to verify it directly against your
 * jar. Confirm it (e.g. via /data get on a filled CEI tank, the same way
 * you confirmed Create's own fluid tank NBT structure earlier) before
 * relying on this.
 */
public final class FluidBridge {

    private static final Logger LOGGER = XPFluidBridgeMod.LOGGER;

    /** TODO: confirm this against your actual CEI jar/version. */
    public static final ResourceLocation LIQUID_XP_ID =
            new ResourceLocation("create_enchantment_industry", "liquid_experience");

    private static RegistryObject<Fluid> liquidExperience;
    private static boolean warnedMissing = false;

    private FluidBridge() {
    }

    /**
     * Lazily creates (but does not resolve/require) a RegistryObject pointing
     * at CEI's Liquid Experience fluid. Safe to call before CEI's own
     * registry events have fired - RegistryObject.create() is lazy.
     */
    private static RegistryObject<Fluid> getTargetFluid() {
        if (liquidExperience == null) {
            liquidExperience = RegistryObject.create(LIQUID_XP_ID, ForgeRegistries.FLUIDS);
            LOGGER.debug("[XPFluidBridge] Bound lazy RegistryObject for target fluid {}", LIQUID_XP_ID);
        }
        return liquidExperience;
    }

    /**
     * Returns the Liquid Experience RegistryObject if it's actually present
     * in the fluid registry (i.e. Create: Enchantment Industry is installed
     * and loaded), otherwise logs a warning ONCE and falls back to whatever
     * fallback the caller supplies - normally PneumaticCraft's own
     * ModFluids.MEMORY_ESSENCE, so the game doesn't crash or silently hand
     * out an empty/invalid fluid if this patcher is used without CEI
     * present.
     */
    public static RegistryObject<Fluid> resolveOrFallback(RegistryObject<Fluid> fallback) {
        RegistryObject<Fluid> target = getTargetFluid();

        if (!target.isPresent()) {
            if (!warnedMissing) {
                LOGGER.warn("[XPFluidBridge] {} was not found in the fluid registry. "
                        + "Is Create: Enchantment Industry installed and loaded? "
                        + "Falling back to PneumaticCraft's vanilla Memory Essence fluid "
                        + "for the remainder of this session.", LIQUID_XP_ID);
                warnedMissing = true;
            }
            return fallback;
        }

        return target;
    }

    /**
     * Called once at mod construction time so the log clearly states,
     * at startup, whether the swap is actually going to work - rather than
     * only surfacing a missing-dependency problem the first time a player
     * interacts with a Memory Stick in-game.
     */
    public static void logStartupDiagnostic() {
        RegistryObject<Fluid> target = getTargetFluid();
        if (target.isPresent()) {
            LOGGER.info("[XPFluidBridge] Startup check OK - {} is registered, redirect is active.", LIQUID_XP_ID);
        } else {
            LOGGER.warn("[XPFluidBridge] Startup check FAILED - {} is NOT registered yet. "
                    + "This is expected if this log line runs before CEI's own fluid registration event; "
                    + "if the warning below ('was not found in the fluid registry') keeps appearing "
                    + "once the world is loaded and you're actually using a Memory Stick, "
                    + "then CEI is genuinely missing or the fluid id above is wrong for your version.",
                    LIQUID_XP_ID);
        }
    }
}
